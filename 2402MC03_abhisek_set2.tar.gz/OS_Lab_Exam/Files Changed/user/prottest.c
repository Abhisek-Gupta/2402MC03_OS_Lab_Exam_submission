#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
  printf("Starting prottest:\n");

  char *p = sbrk(4096);    // Get one page-aligned page with sbrk
  if (p == (char *)-1) {
    printf("sbrk failed\n");
    exit(1);
  }

  *p = 'A';    // Store the character 'A' in it
  printf("Page allocated at %p, stored initial char: '%c'\n", p, *p);

  // A. Call mprotect on the page and show that it can still be read
  if (mprotect(p, 1) < 0) {
    printf("FAILED: mprotect returned error\n");
    exit(1);
  }
  printf("A. mprotect succeeded. Reading protected page: '%c'\n", *p);

  // B. Fork a child that tries to write to the page
  // The child must be killed by the kernel while the parent continues and still sees A
  int pid = fork();
  if (pid < 0) {
    printf("FAILED: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    printf("B. Child trying to write 'B' to write-protected page:\n");
    *p = 'B';
    printf("ERROR: Child was able to write. Trap failed.\n");
    exit(1);
  } else {
    int status = 0;
    wait(&status);
    printf("B. Child terminated. Parent continues and still sees: '%c'\n", *p);
    if (*p != 'A') {
      printf("ERROR: Page content modified.\n");
      exit(1);
    }
  }

  // C. Call munprotect and show that a write of C now succeeds
  if (munprotect(p, 1) < 0) {
    printf("FAILED: munprotect returned error\n");
    exit(1);
  }
  *p = 'C';
  printf("C. munprotect succeeded. Wrote 'C' to page, now reads: '%c'\n", *p);
  if (*p != 'C') {
    printf("ERROR: Write of 'C' failed.\n");
    exit(1);
  }

  /* D. Show that mprotect returns -1 for:
   - unaligned address
   - len = 0
   - range beyond the end of the process memory */
  printf("D. Testing mprotect error handling:\n");

  if (mprotect(p + 1, 1) == -1) {
    printf("mprotect(unaligned address) returned -1\n");
  } else {
    printf("ERROR: mprotect(unaligned address) did not return -1\n");
    exit(1);
  }  // Unaligned address

  if (mprotect(p, 0) == -1) {
    printf("mprotect(len = 0) returned -1\n");
  } else {
    printf("ERROR: mprotect(len = 0) did not return -1\n");
    exit(1);
  }  // len = 0

  char *limit = sbrk(0);
  if (mprotect(limit + 4096, 1) == -1) {
    printf("mprotect(beyond end of memory) returned -1\n");
  } else {
    printf("ERROR: mprotect(beyond end of memory) did not return -1\n");
    exit(1);
  }  // Range beyond end of process memory

  printf("Test Ended.\n");
  exit(0);
}
