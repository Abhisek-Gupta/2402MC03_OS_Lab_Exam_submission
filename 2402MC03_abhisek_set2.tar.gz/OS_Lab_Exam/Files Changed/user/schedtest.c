#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int cpu_work(void)
{
  volatile long long cnt = 0;
  for (volatile long long i = 0; i < 50000000LL; i++) {
    cnt += i;
  }
  return (int)cnt;
}

int main(int argc, char *argv[])
{
  int parent_pid = getpid();
  set_priority(parent_pid, 1);
  printf("Parent pid %d set its priority to 1\n", parent_pid);

  int prios[3] = {5, 10, 15};

  for (int i = 0; i < 3; i++) {
    int pid = fork();
    if (pid < 0) {
      printf("fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      cpu_work();      // Child process executes CPU-bound loop
      printf("Priority %d finished\n", prios[i]);
      exit(0);
    } else {
      set_priority(pid, prios[i]);
    }
  }

  for (int i = 0; i < 3; i++) {  // Parent calls wait() three times
    wait(0);
  }

  printf("Test Done\n");
  exit(0);
}
