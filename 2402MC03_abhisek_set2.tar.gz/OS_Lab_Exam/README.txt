Lab Exam (MA3105 - OS) - 17-11-2026
Abhisek Gupta - 2402MC03
Set No. 2 (2nd Shift)

Question 1: Page Protection with mprotect() and munprotect()

- kernel/vm.c: Implemented helper `mprotect_helper()` and functions `mprotect()` and `munprotect()`. They clear/set the `PTE_W` write bit in the page table and flush the TLB (`sfence_vma()`).
- kernel/defs.h: Declared `mprotect()`, `munprotect()`, and `mprotect_helper()` prototypes.
- kernel/syscall.h & kernel/syscall.c: Added system call definitions `SYS_mprotect` (23) and `SYS_munprotect` (24) and linked their handlers.
- kernel/sysproc.c: Implemented wrappers `sys_mprotect()` and `sys_munprotect()` using `argaddr()` and `argint()`.
- user/user.h & user/usys.pl: Added user-space prototypes and system-call stubs for `mprotect()` and `munprotect()`.
- user/prottest.c & Makefile: Created test program verifying read permissions, child write-fault killing, unprotection writable verification, and error edge cases.



Question 2: Priority-Based CPU Scheduler

- kernel/proc.h: Added `int priority` field to `struct proc` (values 1 to 20, 1 being highest priority).
- kernel/proc.c: Initialized `p->priority = 10` in `allocproc()`. Implemented `set_priority(pid, priority)` searching process table with lock to update priority and return old priority. Replaced round-robin loop in `scheduler()` to find the RUNNABLE process with minimum priority number (breaking ties by first in table order) and context switch to it.
- kernel/defs.h: Declared `set_priority(int, int)`.
- kernel/syscall.h, kernel/syscall.c & kernel/sysproc.c: Added system call `SYS_set_priority` (25) and dispatch mechanism.
- user/user.h & user/usys.pl: Added user-space prototype and stub for `set_priority()`.
- user/schedtest.c & Makefile: Created test program where parent runs at priority 1, spawns 3 children with priorities 5, 10, and 15 doing CPU-bound loops, demonstrating priority execution order.
